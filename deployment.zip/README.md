# YBH Baseline Screening Azure Function

Azure Function to integrate Gravity Forms submissions with Microsoft Lists for the baseline screening campaign.

## Architecture

**Flow:** Gravity Forms → Azure Function → Microsoft Lists

## Function Details

### gravityFormsWebhook
- **Trigger:** HTTP POST
- **URL:** `/api/gravityFormsWebhook`
- **Auth Level:** Function (requires function key)
- **Purpose:** Processes Gravity Forms webhook and creates SharePoint list items

## Setup

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Local Settings
Update `local.settings.json` with your values:
- `TENANT_ID`: Your Azure AD tenant ID
- `SHAREPOINT_SITE_URL`: Your SharePoint site URL
- `LIST_NAME`: Name of your SharePoint list

### 3. Run Locally
```bash
npm start
```

### 4. Test Webhook
```bash
curl -X POST http://localhost:7071/api/gravityFormsWebhook \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "input_1_3=John&input_1_6=Smith&input_2=john@example.com&input_3=Example+Primary+School"
```

## Deployment

### Using Azure CLI
```bash
# Login to Azure
az login

# Deploy function app
func azure functionapp publish func-ybh-baseline-screening-prod
```

### Using VS Code
1. Install Azure Functions extension
2. Right-click project folder
3. Select "Deploy to Function App"
4. Choose `func-ybh-baseline-screening-prod`

## Authentication

The function uses **Managed Identity** to authenticate with Microsoft Graph API:

1. Function App has system-assigned managed identity enabled
2. Managed identity has permissions to the SharePoint site
3. No secrets required in configuration

## Environment Variables

### Production Settings (Azure Portal)
- `TENANT_ID`: Azure AD tenant ID
- `SHAREPOINT_SITE_URL`: https://ybhuk.sharepoint.com/sites/YourBrainHealth
- `LIST_NAME`: Baseline Screening Contacts

## Gravity Forms Configuration

### Webhook URL
`https://func-ybh-baseline-screening-prod-f4c0d8c2erd5ayc0.australiaeast-01.azurewebsites.net/api/gravityFormsWebhook?code=[FUNCTION_KEY]`

### Expected Fields
- `input_1_3`: First Name (or `input_1` for full name)
- `input_1_6`: Last Name  
- `input_2`: Email Address
- `input_3`: School Name

## Monitoring

- **Application Insights:** Enabled for logging and monitoring
- **Logs:** View in Azure portal under Function App → Monitor
- **Alerts:** Configure in Application Insights for error notifications

## Troubleshooting

### Common Issues
1. **Authentication errors**: Check managed identity permissions
2. **List not found**: Verify `LIST_NAME` matches exactly
3. **Field mapping errors**: Check Gravity Forms field IDs
4. **CORS errors**: Ensure CORS is configured for webhook domain

### Debug Locally
```bash
# Enable detailed logging
export AZURE_LOG_LEVEL=verbose
npm start
```

## Field Mapping

| Gravity Forms Field | SharePoint Column | Description |
|-------------------|------------------|-------------|
| `input_1_3` + `input_1_6` | ParentName | Contact's full name |
| `input_2` | Email | Email address |
| `input_3` | SchoolName | School name |
| Auto-generated | Status | Default: "New" |
| Auto-generated | Source | Default: "School Partnership" |
| Auto-generated | NumberOfChildren | Default: 1 |